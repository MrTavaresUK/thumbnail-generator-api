# Thumbnail Generator

Gerador de thumbnails com frontend em HTML + Tailwind e backend em Node.js + Express + OpenAI API (DALL·E 3).

## Instalação

### Backend
```bash
cd backend
cp .env.example .env
npm install
npm start
```

### Frontend
Abra `frontend/index.html` em seu navegador.