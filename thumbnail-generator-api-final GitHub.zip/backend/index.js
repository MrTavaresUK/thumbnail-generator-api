import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import fetch from 'node-fetch';

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

app.post('/generate', async (req, res) => {
    const { prompt } = req.body;
    if (!prompt) return res.status(400).json({ error: 'Prompt is required' });

    try {
        const response = await fetch(
            `https://api.openai.com/v1/images/generations`,
            {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    prompt,
                    n: 1,
                    size: '1024x1024'
                })
            }
        );
        const data = await response.json();
        if (data?.data?.[0]?.url) {
            res.json({ imageUrl: data.data[0].url });
        } else {
            res.status(500).json({ error: 'No image URL returned' });
        }
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error generating image' });
    }
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));